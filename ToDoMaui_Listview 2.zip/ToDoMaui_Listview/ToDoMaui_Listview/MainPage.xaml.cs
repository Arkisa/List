﻿using System.Collections.ObjectModel;
using System.Linq;

namespace ToDoMaui_Listview;

public partial class MainPage : ContentPage
{
    ObservableCollection<ToDoClass> todoList = new();
    int selectedId = -1;
    int autoId = 1;

    public MainPage()
    {
        InitializeComponent();
        todoLV.ItemsSource = todoList;
    }

    // ADD
    private void AddToDoItem(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(titleEntry.Text))
            return;

        todoList.Add(new ToDoClass
        {
            id = autoId++,
            title = titleEntry.Text.Trim(),
            detail = detailsEditor.Text?.Trim() ?? ""
        });

        ClearFields();
    }

    // SELECT ITEM
    private void TodoLV_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
    {
        if (e.SelectedItem is not ToDoClass item)
            return;

        titleEntry.Text = item.title;
        detailsEditor.Text = item.detail;

        selectedId = item.id;

        addBtn.IsVisible = false;
        editBtn.IsVisible = true;
        cancelBtn.IsVisible = true;
    }

    // EDIT
    private void EditToDoItem(object sender, EventArgs e)
    {
        var item = todoList.FirstOrDefault(x => x.id == selectedId);
        if (item != null)
        {
            item.title = titleEntry.Text?.Trim() ?? "";
            item.detail = detailsEditor.Text?.Trim() ?? "";
        }

        CancelEdit(null, null);
    }

    // DELETE
    private void DeleteToDoItem(object sender, EventArgs e)
    {
        if (sender is not Button button)
            return;

        if (int.TryParse(button.ClassId, out int id))
        {
            var item = todoList.FirstOrDefault(x => x.id == id);
            if (item != null)
                todoList.Remove(item);
        }
    }

    // CANCEL EDIT
    private void CancelEdit(object sender, EventArgs e)
    {
        ClearFields();

        addBtn.IsVisible = true;
        editBtn.IsVisible = false;
        cancelBtn.IsVisible = false;

        todoLV.SelectedItem = null;
        selectedId = -1;
    }

    private void ClearFields()
    {
        titleEntry.Text = string.Empty;
        detailsEditor.Text = string.Empty;
    }
}
